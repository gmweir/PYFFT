from . import swancmap
swanrgb = swancmap.swanrgb
